import { createRouter,createWebHistory } from 'vue-router'

const router = createRouter({
    history:createWebHistory(import.meta.env.BASE_URL),
    routes:[
        {
            path:'/',
            component:() => import('./view/Home.vue')
        },
        {
            path:'/webnovel-sharedata',
            component:() => import('./view/ShareData.vue')
        },
        {
            path:'/user',
            component:() => import("./view/User.vue"),
            children:[
                {
                    path:'login',
                    component:() => import('./components/user/login.vue')
                },
                {
                    path:'register',
                    component:() => import('./components/user/register.vue')
                }
            ]
        }
    ]
})


export default router;