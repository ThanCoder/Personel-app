<script setup>
import Navbar from './components/partials/Navbar.vue'
</script>

<template>
  <div class="app">
    <Navbar/>
    <div class="container">
      <router-view/>
    </div>
  </div>
</template>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-size: 18px;
}
.header {
  font-size: 1.5rem;
  text-align: center;

}
.btn-group{
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin: 10px 0;

}
.btn-group > .right {
  justify-self: flex-end;
  margin-left: auto;
}
.btn-group .btn {
  margin-right: 10px;
  margin-bottom: 10px;
}
.btn {
  display: inline-block;
  padding: 4px 8px;
  outline: none;
  cursor: pointer;
  font-size: 1.3rem;
  background: teal;
  color: #fff;
  text-transform: capitalize;
  text-decoration: none;
  border: none;
}
.btn:hover {
  background: rgb(3, 100, 100);
}
.bg-red {
  background: rgb(230, 60, 60);
}
.bg-red:hover {
  background: rgb(196, 41, 41);
}
.white-text {
  color: #fff;
}

.message {
  width: 100%;
  display: block;
  margin: 10px auto;
  text-align: center;
  font-size: 1.2rem;
  text-transform: capitalize;
}
.red {
  color: red;
}

.container {
  width: 100%;
  margin: 1 auto;
  margin-top: 3rem;
}

.c-form {
  margin: 1px 0;

}
.form-group {
  margin: 10px 0;
}
.c-form label {
  width: 100%;
  font-size: 1.2rem;
  margin-bottom: 10px;
}
.c-form label .msg {
  margin-left: 10px;
  font-size: 17px;
  font-weight: 100;
}
.c-form label .red {
  color: red;
}

.form-text {
  width: 100%;
  padding: 4px 0px;
  font-size: 1.2rem;
  outline: none;
  border: none;
  border-bottom: 2px solid teal;
  margin-bottom: 6px;
}
.form-text:focus {
  background: #fff;
}
</style>
