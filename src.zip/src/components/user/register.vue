<template>
  <div class="register">
      <div class="header">Register</div>
      <form class="c-form">
        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" class="form-text" placeholder="Name" id="name">
        </div>
        <div class="form-group">
          <label for="username">User Name</label>
          <input type="text" class="form-text" placeholder="User Name" id="username">
        </div>
        
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-text" placeholder="Password" id="password">
        </div>
        <div class="form-group">
          <label for="confirm-password">Confirm</label>
          <input type="password" class="form-text" placeholder="Confirm" id="confirm-password">
        </div>
        <div class="btn-group">
          <div class="right">
            <input type="submit" value="Register" class="btn">
          </div>
        </div>
      </form>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>