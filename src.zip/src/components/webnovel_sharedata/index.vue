<template>
  <div class="sharedata-component">
      <ShareDataListVue/>
      <Content/>
  </div>
</template>

<script setup>
import Content from './Content.vue'
import ShareDataListVue from './ShareDataList.vue';
</script>

<style scoped>
.sharedata-component {
  display: flex;
  padding: 10px;
}

</style>