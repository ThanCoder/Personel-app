<template>
  <div class="content">
    <button class="btn">Add Share Data</button>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.content {
    flex: 4;
}

</style>