<template>
  <div class="home-component">
      <div class="header">home-component</div>
      <div class="btn-group">
        <router-link class="btn" to="/webnovel-sharedata" >Web Novel ShareData Files</router-link>
      </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>