
import user from './user'



export default {
   user:{...user}
}