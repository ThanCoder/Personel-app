<template>
  <div class="home">
      <HomeComponent/>
  </div>
</template>

<script setup>
import HomeComponent from '../components/home/index.vue'

</script>

<style>

</style>