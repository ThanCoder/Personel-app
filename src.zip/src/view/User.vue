<template>
  <div class="user">
      <router-view/>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.user {
    width: 80%;
    margin: 5rem auto;
    border: 1px solid #d8d8d8;
    padding: 10px;
}

</style>