<template>
  <div class="share-data">
      <ShareDataComponent/>
  </div>
</template>

<script setup>
import ShareDataComponent from '../components/webnovel_sharedata/index.vue'
</script>

<style scoped>
  .share-data {
    margin-top: 4rem;
  }
</style>