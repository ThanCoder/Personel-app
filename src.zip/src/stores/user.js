import { defineStore } from 'pinia'


const userStore = defineStore('user',{
    state:() => ({
        isLogin:false,
        user:null
    }),
    actions:{
        //
        setLogin(payload){
            this.isLogin = payload;
        },
        setUser(user){
            this.user = user;
        }


        //
    }
})
export default userStore;